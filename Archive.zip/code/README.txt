Name: Kevin Sheng
SID: 3036538844
School email: kevinsheng@berkeley.edu
Website: index.html
Code: All code is contained in CS180 Proj 5A.ipynb. The code is divided into several chunks, and running all of them in order will produce the output image (you may need to provide the inputs and set up an output folder)